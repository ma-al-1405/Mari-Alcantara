import React from 'react'
//Aplicacion de Reforzamiento
//Se crea la carpeta Src donde contiene la carpeta common y el archivo Footer.tsx y importado en Header con Router
const Footer = () => {
    return (
        <div>
            <h1>Footer</h1>
        </div>
    )
}

export default Footer
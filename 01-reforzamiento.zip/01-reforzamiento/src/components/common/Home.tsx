import React from 'react'
//Aplicacion de Reforzamiento
//Se crea la carpeta Src donde contiene la carpeta common y el archivo Home.tsx y importado a Header
//igual se crea la carpeta componenst para tener todas dentro de la misma
const Home = () => {
    return (
        <>
            <h1>Welcom to Home</h1>
            <hr />
        </>
        
    );
}
export default Home
import React from 'react'
//Aplicacion de Reforzamiento
//Se crea la carpeta Src donde contiene la carpeta common y el archivo Default.tsx y importado en Header con Router
const Default = () => {
    return (
        <div>
            <h1>Welcome to Default</h1>
        </div>
    )
}

export default Default
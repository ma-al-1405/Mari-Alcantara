import React from 'react'
const Home = () => {
    return (
        <>
            <h1>Inicio de Home</h1>
            <hr />
        </>
        
    );
}
export default Home
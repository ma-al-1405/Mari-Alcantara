import Paises from './Paises';
const MainHooks = () => {

    return (
        <>
            <h1>Paises en Hook</h1>
            <Paises />
        </>
    );
}
export default MainHooks